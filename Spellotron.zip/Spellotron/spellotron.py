"""
    Author: AbuBakr Ghaznavi
    Created on: 11/27/2018
    Corrects the spelling of words by searching through a dictionary and checking adjacent keys
    It implements different strategies of insertion, deletion and replacement to find actual words
"""
from sys import argv

KEYBOARD_FNAME = "keyboard_letters.txt"
WORDS_FNAME = "american_english.txt"
ALPHABET = "ABCDEDFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz" 
PUNCTUATION = ".![]{}(),;\'\"/\\"
USAGE_STRING = "Usage: python3.7 spellotron.py words/lines [filename]"

def build_keyboard_dictionary():
    """
    Builds a dictionary with a key being the key and all of the keys adjacent characters being the values
    """
    keyboard_dict = {}
    keyboard_file = open(KEYBOARD_FNAME)
    for line in keyboard_file:
        line = line.strip()
        letters = line.split(" ")
        keyboard_dict[letters[0]] = letters[1:len(letters)]
    return keyboard_dict

def sort_word(word):
    """
    Lexicographically sorts a string
    param word: a string that will be lexicographically sorted
    """
    sorted_word = ""
    for char in sorted(word):
        sorted_word += char
    return sorted_word

def build_anagram_dictionary():
    """
    Builds a dictionary of anagrams by mapping sorted sequences of characters to real words that match
    """
    ENGLISH_DICT = {}
    open_file = open(WORDS_FNAME)

    for line in open_file:
        line = line.strip()
        sorted_line = "".join(sorted(line))
        if sorted_line not in ENGLISH_DICT.keys():
            ENGLISH_DICT[sorted_line] = [line]
        else:
            ENGLISH_DICT[sorted_line].append(line)

    return ENGLISH_DICT


KEYBOARD_DICT = build_keyboard_dictionary()
ENGLISH_DICT = build_anagram_dictionary()

def check_usage(argv):
    """
    Checks to make sure that the program is being called appropiately with correct arguments
    param argv: list of strings representing the arguments passed into the program
    """
    valid_mode = True
    valid_arg_count = True
    from_stdin = False
    if len(argv) < 2:
        valid_arg_count = False
        print(USAGE_STRING)
        return False,False
    if argv[1] not in ["words", "lines"]:
        valid_mode = False
        print(USAGE_STRING)
        return False,False
    if valid_mode and valid_arg_count:
        if len(argv) < 3:
            from_stdin = True
            print("reading from stdin")
        return True,from_stdin
    else:
        print(USAGE_STRING)
        return False,False

def read_text(filename):
    """
    Reads the text file into a single stream of characters
    param filename: The name of the file that will be read
    """
    open_file = open(filename)
    lines = open_file.readlines()
    line_count = len(lines)
    text = ""
    for line_idx in range(len(lines)):
        text += lines[line_idx]
        if line_idx < (line_count - 1):
            text += " "
    return text

def quick_is_english(word):
    """
    Using lexicographically sorted dictionary, quickly looks up the existence of a word in a dictionary
    param word: The word that will be searched for
    """
    sorted_word = sorted(word)
    sorted_word = "".join(sorted_word)
    if sorted_word not in ENGLISH_DICT.keys():
        return False
    else:
        possible_words = ENGLISH_DICT[sorted_word]
        return word in possible_words
    
def break_into_words(text):
    """
    Collects all sequences of adjacent alphabetic characters
    param text: the text from which the words will be extracted
    """
    words = [] 
    build_up = ""
    for char_idx in range(len(text)):
        if text[char_idx] not in ALPHABET or char_idx == len(text) - 1:
            if build_up != "":
                if char_idx == len(text) -1:
                    build_up += text[len(text) - 1]
                words.append(build_up)
            build_up = ""
        else:
            build_up += text[char_idx]
    return words
        
def replace_letter(word, idx, letter):
    """
    Replaces a single letter in a word given an index
    param word: The word in which the letter will be replaced
    param idx:  The index at which the letter will be replaced
    param letter: The letter which will be replaced in
    """
    return word[0:idx] + letter + word[idx+1:len(word)] 

def single_letter_replacement(word):
    """
    Finds an english word from the given word by removing a single character
    param word: The word that will be modified
    """
    options = []
    for idx in range(len(word)):
        adjacent_keys = KEYBOARD_DICT[word[idx]]
        for adj_key in adjacent_keys:
            new_word = replace_letter(word, idx, adj_key)
            if quick_is_english(new_word):
                options.append(new_word)
                break
    if options == []:
        return None
    else:
        return options[0]

def insert_letter(word, idx, letter):
    """
    Inserts a single letter into a word at a given index
    param word: The word that will be inserted into
    param idx: The index at which the letter will be inserted
    param letter: The letter that will be inserted
    """
    return word[0:idx] + letter + word[idx:len(word)]

def single_letter_insertion(word):
    """
    Finds an english word by inserting a letter at any given point in the word
    param word: The base word that will be inserted to
    """
    options = []
    for idx in range(len(word)):
        for letter in ALPHABET:
            new_word = insert_letter(word, idx, letter)
            if quick_is_english( new_word ):
                options.append( new_word )
                break
    if options == []:
        return None
    else:
        return options[0]


def remove_letter(word, idx):
    """
    Removes a single letter from the word
    param word: The word that will have a letter remove
    param idx: The index at which the letter will be removed
    """
    return word[0:idx] + word[idx+1:len(word)]

def single_letter_removal(word):
    """
    Finds an english word by removing any letter from the word
    param word: The base word that will have a letter removed
    """
    options = []
    for idx in range(len(word)):
        new_word = remove_letter(word, idx)
        if quick_is_english(new_word):
            options.append(new_word)
            break
    if options == []:
        return None
    else:
        return options[0]


def run_tests():
    """
    Debugging purposes only
    Defines tests that will be used to test the functionality of the strategy functions
    """
    print(list(map(single_letter_replacement, ["inxest","poip","nogger","dead","xxxx"])))
    print( quick_is_english("testes") )
    print(list(map(single_letter_removal, ["graoin", "breain", "gloary"])))
    print(list(map(single_letter_insertion, ["kil", "abndance", "riper"])))


def apply_strategies(word):
    """
    Applies all of the defined strategies (Replacement, Removal, Insertion) on the word to find english matches
    param word: The word that will be modified
    """
    #Try out all strategies. If none work, return none
    one_letter_replaced = single_letter_replacement(word)
    if one_letter_replaced is not None:
        return one_letter_replaced
    one_letter_removed = single_letter_removal(word)
    if one_letter_removed is not None:
        return one_letter_removed
    one_letter_inserted = single_letter_insertion(word)
    if one_letter_inserted is not None:
        return one_letter_inserted
    
    return None

def word_is_capital(word):
    """
    Checks if word is a capital word
    param word: The word that will be checked
    """
    return word[0].isupper()

def capialize(word):
    """
    Capitalizes a word
    param word: The word that will be capitalized
    """
    return word[0].upper() + word[1:]

def try_and_fix(unfixed_text, mode):
    """
    Prints out all the statistics of the program and fixes and checks any spelling errors
    param unfixed_text: The text with all the imperfections and spelling errors
    mode: [string] the mode that will be used to interpret the data
    """
    #Notes
    #Use a dictionary to map each misspelled word to its correctly spelled counterpart
    spell_dict = {}
    words = break_into_words(unfixed_text)
    misspelled_words = []
    corrected_words = []
    unknown_words = []
    word_count = len(words)
    for word in words:
        word = word.strip()
        word_is_cap = word_is_capital(word)
        word = word.lower()
        if not quick_is_english( word ):
            misspelled_words.append(word)
            corrected_word = apply_strategies(word)
            if corrected_word is None:
                unknown_words.append(word)
            else:
                if word_is_cap:
                    word = capitalize(word)
                corrected_words.append(corrected_word)
                spell_dict[word] = corrected_word
    
    fixed_text = unfixed_text
    for misspelled in spell_dict:
        fixed_text = fixed_text.replace(misspelled, spell_dict[misspelled])
        fixed_text = fixed_text.replace("\n ", "\n")
    if mode == "lines":
        print(fixed_text)
    elif mode == "words":
        for misspelled in spell_dict:
            print(misspelled, "->", spell_dict[misspelled])
        print() 

    print(len(words),"words read from file")
    print()
    print(len(corrected_words), "Corrected Words")
    print(list(spell_dict.keys()))
    print()
    print(len(unknown_words), "unknown words")
    print(unknown_words)


    
def main():
    valid_args, reading_stdin = check_usage(argv)
    if not valid_args:
        return

    mode = argv[1]

    if reading_stdin:
        text_data = input("")
    else:
        filename = argv[2]
        text_data = read_text(filename)
    
    #print( has_newline("nigga\n"))
    #print(text_data)
    try_and_fix(text_data, mode)

if __name__ == "__main__":
    main()
